package com.ferbots.vsnap

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.TypedArray
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.util.AttributeSet
import android.util.Size
import android.view.Choreographer
import android.view.LayoutInflater
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.widget.LinearLayout
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.net.toUri
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.ferbots.vsnap.Utility.Companion.freeMemory
import com.ferbots.vsnap.Utility.Companion.getRectF
import com.ferbots.vsnap.Utility.Companion.removeWhitespaces
import com.ferbots.vsnap.Utility.Companion.vlog
import com.snap.camerakit.Session
import com.snap.camerakit.connectOutput
import com.snap.camerakit.inputFrom
import com.snap.camerakit.invoke
import com.snap.camerakit.lenses.LensesComponent
import com.snap.camerakit.lenses.observe
import com.snap.camerakit.lenses.whenHasFirst
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.net.URL
import java.util.Calendar
import kotlin.math.min


class VSnapView(context: Context, attrs: AttributeSet? = null ) : LinearLayout(context, attrs) {
    private var texture: TextureView
    private var screen: LinearLayoutCompat
    private val filedOfView = 50F
    private var filterCompletedWithoutFailing: Boolean = false
    private lateinit var inputSurface: Surface
    private lateinit var inputSurfaceUpdateCallback: Choreographer.FrameCallback
    private val choreographer = Choreographer.getInstance()
    private val closeOnDestroy = mutableListOf<Closeable>()
    private lateinit var failureTimerJob: Job
    private lateinit var session:Session

    /** Enter a valid lens id (public or private) from camera kit */
    var lensId:String = ""

    /** Enter a valid group id (public or private) from camera kit */
    var groupId:String = ""

    /** The size of the input image might not fit the snap canvas so if you set fullScreenFilter to
     * true the output will include the extra space outside the image dimension, if you set it false
     * the output will be cropped excatly to your image dimension */
    var fullScreenFilter:Boolean = false

    /** you should give enough time for the filter to be applied the default time is 10 secs for
     * light weight filter reduce the time keep in mind the filter time will change for different
     * devices so try to give a standard time*/
    var progressTime:Long = 10000L

    /** if lens or group id is wrong or if the filter is not applied the process should be killed
     * after a specific time for that sake you shold give a proper failure time , make sure it is
     * atleast 5-6 secs more than progress time*/
    var failureProgressTime:Long = 20000L

    //TODO() example:- if you use a taj mahal filter which covers 100 percent of the snap canvas but
    // the input image is only 50 percent of snap canvas you don't want he image to be floating on
    // top of taj mahal but if you give gravity to bottom the user image will be constrained to
    // bottom of taj mahal , samewise if you create a filter in which user is flying in the sky
    // in that case you should give top gravity
    /** when the image doesn't fit the complete snap canvas it has to constrained to some side. you
     * can set the preferred gravity to constrain the user image to a specific side, It will be
     * useful when you set fullscreen filter to true*/
    var gravity: SnapCanvasGravity = SnapCanvasGravity.TOP_START

    /** once filter ic applied it has to be converted into resource , with this property you can set
     *  the required output type such as bitmap , uri , file etc.. */
    var outputPreferredType:SnapOutputType = SnapOutputType.BITMAP

    init {
        val inflater = LayoutInflater.from(context)
        inflater.inflate(R.layout.snap_layout, this, true)
        texture = findViewById(R.id.texture)
        screen = findViewById(R.id.screen)
        val data: TypedArray = context.obtainStyledAttributes(attrs, R.styleable.VSnapView )
        val res: Int = data.getResourceId(R.styleable.VSnapView_screenRes, -1)
        if (res != -1){
            screenRes(res)
        }
        val drawableRes = data.getResourceId(R.styleable.VSnapView_screenDrawable , -1)
        if (drawableRes != -1){
            val drawable: Drawable? = ResourcesCompat.getDrawable(resources , drawableRes, null)
            screenDrawable(drawable)
        }
        lensId = data.getString(R.styleable.VSnapView_lens_id)?:""
        groupId = data.getString(R.styleable.VSnapView_group_id)?:""
        progressTime = data.getInteger(R.styleable.VSnapView_progress_time , 10000).toLong()
        gravity = processSnapGravity(data.getInteger(R.styleable.VSnapView_snap_gravity , 0))
        outputPreferredType = processPreferredOutputType(data.getInteger(R.styleable.VSnapView_preferred_output_type , 0))
        failureProgressTime = data.getInteger(R.styleable.VSnapView_failure_time , 20000).toLong()
        fullScreenFilter = data.getBoolean(R.styleable.VSnapView_is_fullscreen_filter, false)
        data.recycle()
    }

    private fun processPreferredOutputType(ordinal: Int): SnapOutputType {
        return when(ordinal){
            0 -> SnapOutputType.BITMAP
            1 -> SnapOutputType.FILE
            2 -> SnapOutputType.URI
            4 -> SnapOutputType.URI_STRING
            else -> SnapOutputType.BITMAP
        }
    }

    private fun processSnapGravity(ordinal:Int):SnapCanvasGravity{
        return when(ordinal){
            0 -> SnapCanvasGravity.TOP_START
            1 -> SnapCanvasGravity.TOP_CENTER
            2 -> SnapCanvasGravity.TOP_END
            3 -> SnapCanvasGravity.BOTTOM_START
            4 -> SnapCanvasGravity.BOTTOM_CENTER
            5 -> SnapCanvasGravity.BOTTOM_END
            6 -> SnapCanvasGravity.MIDDLE_START
            7 -> SnapCanvasGravity.MIDDLE_CENTER
            8 -> SnapCanvasGravity.MIDDLE_END
            else -> SnapCanvasGravity.TOP_START
        }
    }

    private fun screenDrawable(bg: Drawable?) {
        bg?.let { screen.background =  it }
    }

    private fun screenRes(bg: Int?) {
        bg?.let { screen.setBackgroundResource(it)}
    }

    private fun texture():TextureView{
        return texture
    }


    /**
     * apply filter to a static image by passing a drawable file id as input
     *
     * @param context activity or fragment
     * @param imageDrawable need drawable file id as input image
     * @return output with preffer output type , but with filter applied to the input image
     */
    fun applySnapFilter(context: FragmentActivity , imageDrawable:Int , filterStatusListener: (status:FilterAppliedState) -> Unit){
        applyFilter(context , drawable = imageDrawable , resourceType = InputResType.DRAWABLE , outputType = outputPreferredType){
            filterStatusListener(it)
        }
    }

    /**
     * apply filter to a static image by passing a image uri as string
     *
     * @param context activity or fragment
     * @param imageUri need image uri as string of the input image
     * @return output with preffer output type , but with filter applied to the input image
     */
    fun applySnapFilter(context: FragmentActivity , imageUri:String, filterStatusListener: (status:FilterAppliedState) -> Unit){
        applyFilter(context , uri = imageUri , resourceType = InputResType.URI , outputType = outputPreferredType){
            filterStatusListener(it)
        }
    }

    /**
     * apply filter to a static image by passing a image uri
     *
     * @param context activity or fragment
     * @param imageUri need image uri of the input image
     * @return output with preffer output type , but with filter applied to the input image
     */
    fun applySnapFilter(context: FragmentActivity , imageUri: Uri, filterStatusListener: (status:FilterAppliedState) -> Unit){
        applyFilter(context , uri = imageUri.toString() , resourceType = InputResType.URI , outputType = outputPreferredType){
            filterStatusListener(it)
        }
    }

    /**
     * apply filter to a static image by passing bitmap of input
     *
     * @param context activity or fragment
     * @param imageBitmap need bitmap of the input image
     * @return output with preffer output type , but with filter applied to the input image
     */
    fun applySnapFilter(context: FragmentActivity , imageBitmap:Bitmap, filterStatusListener: (status:FilterAppliedState) -> Unit){
        applyFilter(context , bitmap = imageBitmap , resourceType = InputResType.BITMAP , outputType = outputPreferredType){
            filterStatusListener(it)
        }
    }

    @Deprecated("Not yet implemented")
    /**
     * apply filter to a static image by passing Url of an image
     *
     * @param context activity or fragment
     * @param imageUrl need url of the input image
     * @return output with preffer output type , but with filter applied to the input image
     */
    fun applySnapFilter(context: FragmentActivity , imageUrl:URL, filterStatusListener: (status:FilterAppliedState) -> Unit){
        applyFilter(context , url = imageUrl , resourceType = InputResType.URL , outputType = outputPreferredType){
            filterStatusListener(it)
        }
    }
    @SuppressLint("CheckResult")
    private fun applyFilter(
        context:FragmentActivity,
        drawable:Int? = null,
        uri:String? = null,
        bitmap:Bitmap? = null,
        url:URL? = null,
        resourceType:InputResType,
        outputType:SnapOutputType,
        filterStatusListener: (status:FilterAppliedState) -> Unit
    ) {
        val applyFilterEH = CoroutineExceptionHandler { _, e ->
            "exception in applyFilter ${e.printStackTrace()} :-: msg ${e.message}".vlog()
            filterStatusListener(FilterAppliedState.FAILED(SnapError.THREE))
            closeSnap(session)
        }

        val processFileEH = CoroutineExceptionHandler { _, e ->
            "exception in processFileEH ${e.printStackTrace()} :-: msg ${e.message}".vlog()
            filterStatusListener(FilterAppliedState.FAILED(SnapError.FIVE))
            closeSnap(session)
        }
        context.lifecycleScope.launch(Dispatchers.IO + applyFilterEH) {
            filterStatusListener(FilterAppliedState.IN_PROGRESS)
            freeMemory()
            texture.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
            session = Session(context).apply {
                lenses.repository.get(
                    LensesComponent.Repository.QueryCriteria.ById(
                        lensId,
                        groupId
                    )
                ) { result ->
                    result.whenHasFirst { lens ->
                        lenses.processor.apply(lens)
                    }
                }
            }

            failureTimerJob = context.lifecycleScope.launch {
                delay(failureProgressTime)
                if (!filterCompletedWithoutFailing){
                    filterStatusListener(FilterAppliedState.FAILED(SnapError.ZERO))
                    closeSnap(session)
                }
            }

            val inputTextureSize = Size(1080, 1920)
            val inputSurfaceTexture = SurfaceTexture(0).apply {
                setDefaultBufferSize(inputTextureSize.width, inputTextureSize.height)
                detachFromGLContext()
            }
            val input = inputFrom(
                surfaceTexture = inputSurfaceTexture,
                width = inputTextureSize.width,
                height = inputTextureSize.height,
                facingFront = false,
                rotationDegrees = 0,
                horizontalFieldOfView = filedOfView,
                verticalFieldOfView = filedOfView
            )
            closeOnDestroy.add(session.processor.connectInput(input))
            inputSurface = Surface(inputSurfaceTexture)
            val inputImage = context.lifecycleScope.async(Dispatchers.IO + processFileEH ) {
                when(resourceType){
                    InputResType.DRAWABLE -> {
                        BitmapFactory.decodeResource(resources, drawable!!)
                    }
                    InputResType.URI -> {
                        if (uri!!.contains("content:/") && Build.VERSION.SDK_INT >= 29) {
                            val `is`: InputStream? =
                                context.contentResolver.openInputStream(uri.toUri())
                            val inputBitmap = BitmapFactory.decodeStream(`is`)
                            `is`?.close()
                            inputBitmap
                        } else {
                            BitmapFactory.decodeFile(uri)
                        }
                    }
                    InputResType.URL -> TODO()
                    InputResType.BITMAP -> {
                        bitmap!!
                    }
                }
            }.await()
            if (inputImage != null) {
                if ( inputImage.height <= 0 || inputImage.width <= 0) {
                    filterStatusListener(FilterAppliedState.FAILED(SnapError.ONE))
                    closeSnap(session)
                    return@launch
                }
            }else{
                closeSnap(session)
                filterStatusListener(FilterAppliedState.FAILED(SnapError.FIVE))
                return@launch
            }
            val scale = min(
                inputTextureSize.width.toFloat() / inputImage.width,
                inputTextureSize.height.toFloat() / inputImage.height
            )
            val canvasWidth = inputTextureSize.width.toFloat()
            val canvasHeight = inputTextureSize.height.toFloat()
            val imgWidth = (inputImage.width.toFloat()) * scale
            val imgHeight = (inputImage.height.toFloat()) * scale
            val dstRect = getRectF(
                gravity,
                SnapMetrics(imgWidth, imgHeight, canvasWidth, canvasHeight)
            )

            session.lenses.processor.observe(onEvent = { event ->
                when (event) {
                    is LensesComponent.Processor.Event.Applied -> {}
                    is LensesComponent.Processor.Event.FirstFrameProcessed -> {
                        context.lifecycleScope.launch(Dispatchers.IO) {
                            "FirstFrameProcessed".vlog()
                            closeOnDestroy.add(session.processor.connectOutput(texture()))
                            filterCompletedWithoutFailing = true
                            delay(progressTime)
                            val finalBitmap = texture.bitmap
                            closeSnap(session)
                            if (finalBitmap != null) {
                                processCameraKitOutput(
                                    finalBitmap,
                                    SnapMetrics(imgWidth, imgHeight, canvasWidth, canvasHeight),
                                    dstRect,
                                    inputImage,
                                    context,
                                    fullScreenFilter ,
                                    outputType
                                ){
                                    filterStatusListener(it)
                                }
                            } else {
                                filterStatusListener(FilterAppliedState.FAILED(SnapError.TWO))
                            }
                        }
                    }
                    LensesComponent.Processor.Event.Idle -> {}
                }
            })

            inputSurfaceUpdateCallback = object : Choreographer.FrameCallback {
                override fun doFrame(frameTimeNanos: Long) {
                    if (inputSurface.isValid) {
                        val canvas = inputSurface.lockCanvas(null)
                        try {
                            canvas.drawBitmap(inputImage, null, dstRect, null)
                        } finally {
                            if (inputSurface.isValid) {
                                inputSurface.unlockCanvasAndPost(canvas)
                            }
                        }
                        choreographer.postFrameCallback(this)
                    }
                }
            }

            choreographer.postFrameCallback(inputSurfaceUpdateCallback)
        }
    }

    private fun processCameraKitOutput(
        bitmap: Bitmap,
        metrics: SnapMetrics,
        destRect: RectF,
        inputImage: Bitmap,
        context: FragmentActivity,
        isFullScreen:Boolean,
        outputType: SnapOutputType,
        filterStatusListener: (status:FilterAppliedState) -> Unit
    ) {
        val processCameraKitOutputEH = CoroutineExceptionHandler { _, e ->
            "exception in processCameraKitOutput ${e.printStackTrace()} msg:-: ${e.message}".vlog()
            filterStatusListener(FilterAppliedState.FAILED(SnapError.FOUR))
        }
        context.lifecycleScope.launch(Dispatchers.IO + processCameraKitOutputEH){
            val finalScaledBitmap = if (!isFullScreen ) {
                val userBitmapVsTextureBitmap = (bitmap.width).div(metrics.canvasWidth)
                val croppedBitmapFromTextureView = Bitmap.createBitmap(
                    bitmap,
                    ((destRect.left) * userBitmapVsTextureBitmap).toInt(),
                    (destRect.top * userBitmapVsTextureBitmap).toInt(),
                    ((destRect.right - destRect.left) * userBitmapVsTextureBitmap).toInt(),
                    ((destRect.bottom - destRect.top) * userBitmapVsTextureBitmap).toInt()
                )
                 Bitmap.createScaledBitmap(
                    croppedBitmapFromTextureView,
                    inputImage.width,
                    inputImage.height,
                    false
                )
            } else {
                Bitmap.createScaledBitmap(
                    bitmap,
                    metrics.canvasWidth.toInt(),
                    metrics.canvasHeight.toInt(), false
                )
            }

            when(outputType){
                SnapOutputType.BITMAP -> {
                    filterStatusListener(FilterAppliedState.SUCCESS(SnapOutputType.BITMAP , finalScaledBitmap))
                }
                SnapOutputType.FILE,SnapOutputType.URI, SnapOutputType.URI_STRING -> {
                    val file = File(
                        context.filesDir,
                        Calendar.getInstance().time.toString().removeWhitespaces() + "snap.jpg"
                    )
                    val fOut = FileOutputStream(file)
                    val populateFile = finalScaledBitmap!!.compress(Bitmap.CompressFormat.PNG, 100, fOut)
                    if (populateFile) {
                        fOut.flush()
                        fOut.close()
                    }
                    when(outputType){
                        SnapOutputType.FILE -> {
                            filterStatusListener(FilterAppliedState.SUCCESS(SnapOutputType.FILE , file.absoluteFile))
                        }
                        SnapOutputType.URI -> {
                            filterStatusListener(FilterAppliedState.SUCCESS(SnapOutputType.URI , file.absolutePath.toUri()))
                        }
                        SnapOutputType.URI_STRING -> {
                            filterStatusListener(FilterAppliedState.SUCCESS(SnapOutputType.URI_STRING , file.absolutePath))
                        }
                        else -> {}
                    }
                }
            }
        }
    }

    private fun closeSnap(session: Session) {
        try {
            if (this::failureTimerJob.isInitialized){
                if (failureTimerJob.isActive){
                    failureTimerJob.cancel("function already ended")
                }
            }
            if (::inputSurfaceUpdateCallback.isInitialized) {
                choreographer.removeFrameCallback(inputSurfaceUpdateCallback)
            }
            if (this::inputSurface.isInitialized) {
                inputSurface.release()
            }
            closeOnDestroy.forEach { it.close() }
            if (this::session.isInitialized){
                session.close()
            }
            if (::inputSurfaceUpdateCallback.isInitialized) {
                choreographer.removeFrameCallback(inputSurfaceUpdateCallback)
            }
            freeMemory()
        }catch (e:Exception){
            "exception in closeSnap ${e.printStackTrace()} msg:-: ${e.message}".vlog()
        }
    }



}