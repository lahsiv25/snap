package com.ferbots.vsnap

enum class SnapCanvasGravity {
    TOP_START,
    TOP_CENTER,
    TOP_END,
    BOTTOM_START,
    BOTTOM_CENTER,
    BOTTOM_END,
    MIDDLE_START,
    MIDDLE_CENTER,
    MIDDLE_END
}