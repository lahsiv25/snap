package com.ferbots.vsnap

enum class SnapError(val code:Int ,val error:String ,  val message:String){
    ZERO(0 , "TIME_LIMIT_EXCEEDED" ,
        "Filter not applied or even initialized " +
                "till failure time got over, check " +
                "if the lens and group id is proper or " +
                "increase the failure time with failureProgressTime " +
                "property to give some extra time for the filter " +
                "to apply"),
    ONE(1 , "INVALID_IMAGE" ,
        "After bitmap is processed one of the bitmap " +
                "dimension(height or width) is zero " +
                "so pass a proper image"),
    TWO(2 , "EMPTY_BITMAP" ,
        "Snap camera kit returns a null bitmap in place " +
                "of the filter applied bitmap there must " +
                "be some error with camera kit impl " +
                "contact the creator with proper logs "),
    THREE(3 , "ERROR_WHILE_APPLYING_FILTER",
        "VSnap crashed while applying filter " +
                "contact the creator with proper logs "
    ),
    FOUR( 4 , "ERROR_WHILE_PROCESSING_FILTERED_BITMAP",
        "Filter applied properly but facing error " +
                "to process the bitmap into preferred output ," +
                "change the outputPrefferedType property " +
                "and try with different output type"),
    FIVE(5 , "WRONG_FILE" ,
        "The uri you gave for input image is not valid" +
                " or you disabled the file access permission:-: file not found exception")
}
