package com.ferbots.vsnap

import android.graphics.RectF
import android.util.Log

class Utility {
    companion object {
        fun Any?.vlog() = Log.e("vsnap_log", ":-: ${this?:"null"} :-:")

        fun String.removeWhitespaces() = replace(" ", "")

        fun freeMemory() {
            try {
                System.runFinalization()
                Runtime.getRuntime().gc()
                System.gc()
            }catch (e:Exception){
                "exception in freeMemory ${e.printStackTrace()}".vlog()
            }
        }


        fun getRectF(
            gravity: SnapCanvasGravity,
            metrics: SnapMetrics,
        ): RectF {
            return when(gravity){
                SnapCanvasGravity.TOP_START -> {
                    RectF(0F, 0F,metrics.imgWidth, metrics.imgHeight)
                }
                SnapCanvasGravity.TOP_END -> {
                    RectF(metrics.canvasWidth - metrics.imgWidth,0F,metrics.canvasWidth,metrics.imgHeight)
                }
                SnapCanvasGravity.BOTTOM_START -> {
                    RectF(0F,metrics.canvasHeight - metrics.imgHeight,metrics.imgWidth,metrics.canvasHeight)
                }
                SnapCanvasGravity.BOTTOM_END -> {
                    RectF(metrics.canvasWidth - metrics.imgWidth,metrics.canvasHeight - metrics.imgHeight,metrics.canvasWidth,metrics.canvasHeight)
                }
                SnapCanvasGravity.MIDDLE_START -> {
                    RectF( 0F,(metrics.canvasHeight-metrics.imgHeight)/2, metrics.imgWidth,(metrics.canvasHeight-metrics.imgHeight)/2 )
                }
                SnapCanvasGravity.MIDDLE_END -> {
                    RectF( metrics.canvasWidth - metrics.imgWidth,(metrics.canvasHeight-metrics.imgHeight)/2, metrics.canvasWidth,(metrics.canvasHeight-metrics.imgHeight)/2 )
                }
                SnapCanvasGravity.TOP_CENTER -> {
                    RectF((metrics.canvasWidth-metrics.imgWidth)/2,0F,(metrics.canvasWidth+metrics.imgWidth)/2,metrics.imgHeight)
                }
                SnapCanvasGravity.BOTTOM_CENTER -> {
                    RectF((metrics.canvasWidth-metrics.imgWidth)/2,metrics.canvasHeight-metrics.imgHeight,(metrics.canvasWidth+metrics.imgWidth)/2,metrics.canvasHeight)
                }
                SnapCanvasGravity.MIDDLE_CENTER -> {
                    RectF((metrics.canvasWidth-metrics.imgWidth)/2,(metrics.canvasHeight-metrics.imgHeight)/2,(metrics.canvasWidth+metrics.imgWidth)/2,(metrics.canvasHeight+metrics.imgHeight)/2)
                }
            }
        }
    }
}