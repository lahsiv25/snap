package com.ferbots.vsnap

data class SnapMetrics(val imgWidth:Float, val imgHeight:Float ,val canvasWidth:Float , val canvasHeight:Float)
