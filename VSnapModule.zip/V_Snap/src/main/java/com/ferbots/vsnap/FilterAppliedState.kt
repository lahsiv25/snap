package com.ferbots.vsnap

sealed class FilterAppliedState {
    data class SUCCESS(val outputType: SnapOutputType , val result:Any ):FilterAppliedState()
    object IN_PROGRESS:FilterAppliedState()
    data class FAILED(val error: SnapError):FilterAppliedState()
}