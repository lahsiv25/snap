package com.ferbots.vsnap

enum class InputResType {
    DRAWABLE,
    URI,
    URL,
    BITMAP
}