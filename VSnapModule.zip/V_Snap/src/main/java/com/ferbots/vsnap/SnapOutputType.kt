package com.ferbots.vsnap

enum class SnapOutputType {
    BITMAP,
    FILE,
    URI,
    URI_STRING
}